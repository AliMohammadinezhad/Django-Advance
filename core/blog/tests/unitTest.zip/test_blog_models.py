from django.test import TestCase
from datetime import datetime

from ..models import Post

from accounts.models import User, Profile


class TestPostModel(TestCase):
    def setUp(self):
        self.user_obj = User.objects.create_user(
            email="user@example.com", password="password"
        )
        self.profile = Profile.objects.create(
            user=self.user_obj,
            first_name="first_name",
            last_name="last_name",
            description="description",
        )
        

    def test_create_post_with_valid_data(self):
        post = Post.objects.create(
            author=self.profile,
            title="title",
            content="content",
            status=True,
            category=None,
            published_date=datetime.now()
        )
        self.assertTrue(Post.objects.filter(pk=post.id).exists())
        self.assertEqual(post.title, "title")
        
        
